package com.warehouse.entity;

import lombok.Data;
import javax.persistence.*;

@Data
@Entity
@Table(name = "warehouse_in_detail")
public class WarehouseInDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "in_id", nullable = false)
    private Long inId;

    @Column(name = "material_id", nullable = false)
    private Long materialId;

    @Column(name = "quantity", nullable = false)
    private Integer quantity;

    @Column(name = "unit_price", nullable = false, precision = 10, scale = 2)
    private Double unitPrice;

    @Column(name = "amount", nullable = false, precision = 10, scale = 2)
    private Double amount;

    @Column(name = "batch_no", length = 30)
    private String batchNo;
}