package com.warehouse.entity;

import lombok.Data;
import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "material_ledger", uniqueConstraints = {
        @UniqueConstraint(name = "uk_name_spec_material", columnNames = {"name", "specification", "material"})
})
public class MaterialLedger {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "code", nullable = false, unique = true, length = 30)
    private String code;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "specification", nullable = false, length = 50)
    private String specification;

    @Column(name = "material", nullable = false, length = 50)
    private String material;

    @Column(name = "supplier", length = 100)
    private String supplier;

    @Column(name = "brand", length = 50)
    private String brand;

    @Column(name = "category_id", nullable = false)
    private Long categoryId;

    @Column(name = "create_time", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createTime;

    @Column(name = "update_time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateTime;

    // 设置创建时间和更新时间的回调方法
    @PrePersist
    protected void onCreate() {
        createTime = new Date();
        updateTime = new Date();
    }

    @PreUpdate
    protected void onUpdate() {
        updateTime = new Date();
    }
}