package com.warehouse.entity;

import lombok.Data;
import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "warehouse_in")
public class WarehouseIn {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "code", nullable = false, unique = true, length = 30)
    private String code;

    @Column(name = "warehouse_id", nullable = false)
    private Long warehouseId;

    @Column(name = "operator", nullable = false, length = 20)
    private String operator;

    @Column(name = "remark", length = 200)
    private String remark;

    @Column(name = "create_time", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createTime;

    // 设置创建时间的回调方法
    @PrePersist
    protected void onCreate() {
        createTime = new Date();
    }
}