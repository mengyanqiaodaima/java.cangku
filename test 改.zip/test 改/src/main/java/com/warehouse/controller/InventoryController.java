package com.warehouse.controller;

import com.warehouse.common.Result;
import com.warehouse.entity.Inventory;
import com.warehouse.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/inventory")
public class InventoryController {
    @Autowired
    private InventoryService inventoryService;
    
    /**
     * 根据物资ID和仓库ID查询库存
     */
    @GetMapping("/material-warehouse/{materialId}/{warehouseId}")
    public Result<List<Inventory>> getByMaterialIdAndWarehouseId(
            @PathVariable Long materialId, 
            @PathVariable Long warehouseId) {
        try {
            List<Inventory> inventory = inventoryService.findByMaterialIdAndWarehouseId(materialId, warehouseId);
            return Result.success(inventory);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 根据仓库ID查询库存
     */
    @GetMapping("/warehouse/{warehouseId}")
    public Result<List<Inventory>> getByWarehouseId(@PathVariable Long warehouseId) {
        try {
            List<Inventory> inventory = inventoryService.findByWarehouseId(warehouseId);
            return Result.success(inventory);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 查询所有库存
     */
    @GetMapping("/list")
    public Result<List<Inventory>> list() {
        try {
            List<Inventory> inventory = inventoryService.findAll();
            return Result.success(inventory);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 按物资编码查询库存信息(含物资详情)
     */
    @GetMapping("/material-code/{materialCode}")
    public Result<List<Map<String, Object>>> getByMaterialCode(@PathVariable String materialCode) {
        try {
            List<Map<String, Object>> inventory = inventoryService.findInventoryByMaterialCode(materialCode);
            return Result.success(inventory);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 按物资分类汇总查询库存信息
     */
    @GetMapping("/category/{categoryId}")
    public Result<List<Map<String, Object>>> getByCategoryId(@PathVariable Long categoryId) {
        try {
            List<Map<String, Object>> inventory = inventoryService.findInventoryByCategoryId(categoryId);
            return Result.success(inventory);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
}
