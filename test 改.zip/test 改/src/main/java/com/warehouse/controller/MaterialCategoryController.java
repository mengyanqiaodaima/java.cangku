package com.warehouse.controller;

import com.warehouse.common.Result;
import com.warehouse.entity.MaterialCategory;
import com.warehouse.service.MaterialCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/material-category")
public class MaterialCategoryController {
    @Autowired
    private MaterialCategoryService materialCategoryService;
    
    /**
     * 新增物资分类
     */
    @PostMapping
    public Result<MaterialCategory> save(@RequestBody MaterialCategory materialCategory) {
        try {
            MaterialCategory savedCategory = materialCategoryService.save(materialCategory);
            return Result.success(savedCategory);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 更新物资分类
     */
    @PutMapping
    public Result<MaterialCategory> update(@RequestBody MaterialCategory materialCategory) {
        try {
            MaterialCategory updatedCategory = materialCategoryService.update(materialCategory);
            return Result.success(updatedCategory);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 删除物资分类
     */
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        try {
            materialCategoryService.deleteById(id);
            return Result.success();
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 根据ID查询物资分类
     */
    @GetMapping("/{id}")
    public Result<MaterialCategory> getById(@PathVariable Long id) {
        try {
            MaterialCategory category = materialCategoryService.findById(id);
            return Result.success(category);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 根据编码查询物资分类
     */
    @GetMapping("/code/{code}")
    public Result<MaterialCategory> getByCode(@PathVariable String code) {
        try {
            MaterialCategory category = materialCategoryService.findByCode(code);
            return Result.success(category);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 查询所有物资分类
     */
    @GetMapping("/list")
    public Result<List<MaterialCategory>> list() {
        try {
            List<MaterialCategory> categories = materialCategoryService.findAll();
            return Result.success(categories);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 根据父分类ID查询子分类
     */
    @GetMapping("/children/{parentId}")
    public Result<List<MaterialCategory>> getChildrenByParentId(@PathVariable Long parentId) {
        try {
            List<MaterialCategory> categories = materialCategoryService.findByParentId(parentId);
            return Result.success(categories);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
}