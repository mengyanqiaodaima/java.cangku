package com.warehouse.controller;

import com.warehouse.common.Result;
import com.warehouse.entity.Warehouse;
import com.warehouse.service.WarehouseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/warehouse")
public class WarehouseController {
    @Autowired
    private WarehouseService warehouseService;
    
    /**
     * 新增仓库
     */
    @PostMapping
    public Result<Warehouse> save(@RequestBody Warehouse warehouse) {
        try {
            Warehouse savedWarehouse = warehouseService.save(warehouse);
            return Result.success(savedWarehouse);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 更新仓库
     */
    @PutMapping
    public Result<Warehouse> update(@RequestBody Warehouse warehouse) {
        try {
            Warehouse updatedWarehouse = warehouseService.update(warehouse);
            return Result.success(updatedWarehouse);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 删除仓库
     */
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        try {
            warehouseService.deleteById(id);
            return Result.success();
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 根据ID查询仓库
     */
    @GetMapping("/{id}")
    public Result<Warehouse> getById(@PathVariable Long id) {
        try {
            Warehouse warehouse = warehouseService.findById(id);
            return Result.success(warehouse);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 根据编码查询仓库
     */
    @GetMapping("/code/{code}")
    public Result<Warehouse> getByCode(@PathVariable String code) {
        try {
            Warehouse warehouse = warehouseService.findByCode(code);
            return Result.success(warehouse);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 查询所有仓库
     */
    @GetMapping("/list")
    public Result<List<Warehouse>> list() {
        try {
            List<Warehouse> warehouses = warehouseService.findAll();
            return Result.success(warehouses);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
}