package com.warehouse.controller;

import com.warehouse.common.Result;
import com.warehouse.entity.WarehouseIn;
import com.warehouse.service.WarehouseInService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/warehouse-in")
public class WarehouseInController {
    @Autowired
    private WarehouseInService warehouseInService;
    
    /**
     * 创建入库单
     */
    @PostMapping
    public Result<WarehouseIn> create(@RequestBody WarehouseIn warehouseIn) {
        try {
            WarehouseIn createdWarehouseIn = warehouseInService.createWarehouseIn(warehouseIn);
            return Result.success(createdWarehouseIn);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 根据ID查询入库单
     */
    @GetMapping("/{id}")
    public Result<WarehouseIn> getById(@PathVariable Long id) {
        try {
            WarehouseIn warehouseIn = warehouseInService.findById(id);
            return Result.success(warehouseIn);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 根据编码查询入库单
     */
    @GetMapping("/code/{code}")
    public Result<WarehouseIn> getByCode(@PathVariable String code) {
        try {
            WarehouseIn warehouseIn = warehouseInService.findByCode(code);
            return Result.success(warehouseIn);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 查询所有入库单
     */
    @GetMapping("/list")
    public Result<List<WarehouseIn>> list() {
        try {
            List<WarehouseIn> warehouseIns = warehouseInService.findAll();
            return Result.success(warehouseIns);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
}
