package com.warehouse.controller;

import com.warehouse.common.Result;
import com.warehouse.entity.WarehouseOut;
import com.warehouse.service.WarehouseOutService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/warehouse-out")
public class WarehouseOutController {
    @Autowired
    private WarehouseOutService warehouseOutService;
    
    /**
     * 创建出库单
     */
    @PostMapping
    public Result<WarehouseOut> create(@RequestBody WarehouseOut warehouseOut) {
        try {
            WarehouseOut createdWarehouseOut = warehouseOutService.createWarehouseOut(warehouseOut);
            return Result.success(createdWarehouseOut);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 根据ID查询出库单
     */
    @GetMapping("/{id}")
    public Result<WarehouseOut> getById(@PathVariable Long id) {
        try {
            WarehouseOut warehouseOut = warehouseOutService.findById(id);
            return Result.success(warehouseOut);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 根据编码查询出库单
     */
    @GetMapping("/code/{code}")
    public Result<WarehouseOut> getByCode(@PathVariable String code) {
        try {
            WarehouseOut warehouseOut = warehouseOutService.findByCode(code);
            return Result.success(warehouseOut);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 查询所有出库单
     */
    @GetMapping("/list")
    public Result<List<WarehouseOut>> list() {
        try {
            List<WarehouseOut> warehouseOuts = warehouseOutService.findAll();
            return Result.success(warehouseOuts);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
}
