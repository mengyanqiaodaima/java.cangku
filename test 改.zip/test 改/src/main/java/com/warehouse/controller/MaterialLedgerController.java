package com.warehouse.controller;

import com.warehouse.common.Result;
import com.warehouse.entity.MaterialLedger;
import com.warehouse.service.MaterialLedgerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/material-ledger")
public class MaterialLedgerController {
    @Autowired
    private MaterialLedgerService materialLedgerService;
    
    /**
     * 新增物资
     */
    @PostMapping
    public Result<MaterialLedger> save(@RequestBody MaterialLedger materialLedger) {
        try {
            // 验证物资编码唯一性
            if (!materialLedgerService.isCodeUnique(materialLedger)) {
                return Result.error("同一名称、规格、材质的物资不能使用相同编码");
            }
            MaterialLedger savedMaterial = materialLedgerService.save(materialLedger);
            return Result.success(savedMaterial);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 更新物资
     */
    @PutMapping
    public Result<MaterialLedger> update(@RequestBody MaterialLedger materialLedger) {
        try {
            // 验证物资编码唯一性
            if (!materialLedgerService.isCodeUnique(materialLedger)) {
                return Result.error("同一名称、规格、材质的物资不能使用相同编码");
            }
            MaterialLedger updatedMaterial = materialLedgerService.update(materialLedger);
            return Result.success(updatedMaterial);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 删除物资
     */
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        try {
            materialLedgerService.deleteById(id);
            return Result.success();
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 根据ID查询物资
     */
    @GetMapping("/{id}")
    public Result<MaterialLedger> getById(@PathVariable Long id) {
        try {
            MaterialLedger material = materialLedgerService.findById(id);
            return Result.success(material);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 根据编码查询物资
     */
    @GetMapping("/code/{code}")
    public Result<MaterialLedger> getByCode(@PathVariable String code) {
        try {
            MaterialLedger material = materialLedgerService.findByCode(code);
            return Result.success(material);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 查询所有物资
     */
    @GetMapping("/list")
    public Result<List<MaterialLedger>> list() {
        try {
            List<MaterialLedger> materials = materialLedgerService.findAll();
            return Result.success(materials);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
    
    /**
     * 验证物资编码唯一性
     */
    @PostMapping("/check-code")
    public Result<Boolean> checkCode(@RequestBody MaterialLedger materialLedger) {
        try {
            boolean isUnique = materialLedgerService.isCodeUnique(materialLedger);
            return Result.success(isUnique);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
}