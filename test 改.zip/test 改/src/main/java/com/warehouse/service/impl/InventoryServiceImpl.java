package com.warehouse.service.impl;

import com.warehouse.entity.Inventory;
import com.warehouse.entity.MaterialCategory;
import com.warehouse.entity.MaterialLedger;
import com.warehouse.entity.Warehouse;
import com.warehouse.repository.InventoryRepository;
import com.warehouse.repository.MaterialLedgerRepository;
import com.warehouse.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;
import java.util.Map;

@Service
public class InventoryServiceImpl implements InventoryService {
    @Autowired
    private InventoryRepository inventoryRepository;
    
    @Autowired
    private MaterialLedgerRepository materialLedgerRepository;
    
    @PersistenceContext
    private EntityManager entityManager;
    
    @Override
    public List<Inventory> findByMaterialIdAndWarehouseId(Long materialId, Long warehouseId) {
        return inventoryRepository.findByMaterialIdAndWarehouseId(materialId, warehouseId);
    }
    
    @Override
    public List<Inventory> findByWarehouseId(Long warehouseId) {
        return inventoryRepository.findByWarehouseId(warehouseId);
    }
    
    @Override
    public List<Inventory> findAll() {
        return inventoryRepository.findAll();
    }
    
    @Override
    public List<Map<String, Object>> findInventoryByMaterialCode(String materialCode) {
        // 使用JPQL查询按物资编码的库存信息，关联物资台账表
        String jpql = "SELECT i.id as inventoryId, i.quantity, i.batchNo, i.warehouseId, " +
                      "m.id as materialId, m.code as materialCode, m.name as materialName, m.specification, m.material, " +
                      "w.id as warehouseId, w.code as warehouseCode, w.name as warehouseName " +
                      "FROM Inventory i " +
                      "JOIN MaterialLedger m ON i.materialId = m.id " +
                      "JOIN Warehouse w ON i.warehouseId = w.id " +
                      "WHERE m.code = :materialCode";
        
        Query query = entityManager.createQuery(jpql);
        query.setParameter("materialCode", materialCode);
        
        return query.getResultList();
    }
    
    @Override
    public List<Map<String, Object>> findInventoryByCategoryId(Long categoryId) {
        // 使用JPQL查询按物资分类汇总的库存信息，关联物资台账表和物资分类表
        String jpql = "SELECT mc.id as categoryId, mc.name as categoryName, " +
                      "m.id as materialId, m.code as materialCode, m.name as materialName, " +
                      "SUM(i.quantity) as totalQuantity, w.id as warehouseId, w.name as warehouseName " +
                      "FROM Inventory i " +
                      "JOIN MaterialLedger m ON i.materialId = m.id " +
                      "JOIN MaterialCategory mc ON m.categoryId = mc.id " +
                      "JOIN Warehouse w ON i.warehouseId = w.id " +
                      "WHERE mc.id = :categoryId " +
                      "GROUP BY mc.id, mc.name, m.id, m.code, m.name, w.id, w.name";
        
        Query query = entityManager.createQuery(jpql);
        query.setParameter("categoryId", categoryId);
        
        return query.getResultList();
    }
}