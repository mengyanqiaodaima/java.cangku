package com.warehouse.service.impl;

import com.warehouse.entity.Warehouse;
import com.warehouse.repository.WarehouseRepository;
import com.warehouse.service.WarehouseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WarehouseServiceImpl implements WarehouseService {
    @Autowired
    private WarehouseRepository warehouseRepository;
    
    @Override
    public Warehouse save(Warehouse warehouse) {
        return warehouseRepository.save(warehouse);
    }
    
    @Override
    public Warehouse update(Warehouse warehouse) {
        return warehouseRepository.save(warehouse);
    }
    
    @Override
    public void deleteById(Long id) {
        warehouseRepository.deleteById(id);
    }
    
    @Override
    public Warehouse findById(Long id) {
        return warehouseRepository.findById(id).orElse(null);
    }
    
    @Override
    public Warehouse findByCode(String code) {
        return warehouseRepository.findByCode(code);
    }
    
    @Override
    public List<Warehouse> findAll() {
        return warehouseRepository.findAll();
    }
}
