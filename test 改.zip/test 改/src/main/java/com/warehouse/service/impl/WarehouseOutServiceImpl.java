package com.warehouse.service.impl;

import com.warehouse.entity.Inventory;
import com.warehouse.entity.WarehouseOut;
import com.warehouse.entity.WarehouseOutDetail;
import com.warehouse.repository.InventoryRepository;
import com.warehouse.repository.WarehouseOutDetailRepository;
import com.warehouse.repository.WarehouseOutRepository;
import com.warehouse.service.WarehouseOutService;
import com.warehouse.utils.CodeGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class WarehouseOutServiceImpl implements WarehouseOutService {
    @Autowired
    private WarehouseOutRepository warehouseOutRepository;
    
    @Autowired
    private WarehouseOutDetailRepository warehouseOutDetailRepository;
    
    @Autowired
    private InventoryRepository inventoryRepository;
    
    @Override
    @Transactional
    public WarehouseOut createWarehouseOut(WarehouseOut warehouseOut, List<WarehouseOutDetail> details) {
        // 生成出库单编码
        String code = CodeGenerator.generateOutCode();
        warehouseOut.setCode(code);
        
        // 保存出库单
        WarehouseOut savedOut = warehouseOutRepository.save(warehouseOut);
        
        // 保存出库单明细并更新库存
        for (WarehouseOutDetail detail : details) {
            // 设置出库单ID
            detail.setOutId(savedOut.getId());
            
            // 保存明细
            warehouseOutDetailRepository.save(detail);
            
            // 更新库存
            updateInventory(savedOut.getWarehouseId(), detail);
        }
        
        return savedOut;
    }
    
    /**
     * 更新库存信息（减少库存数量）
     * 如果库存不足，抛出异常
     */
    private void updateInventory(Long warehouseId, WarehouseOutDetail detail) {
        // 查询当前库存
        Inventory inventory = inventoryRepository.findByMaterialIdAndWarehouseIdAndBatchNo(
                detail.getMaterialId(), warehouseId, detail.getBatchNo());
        
        if (inventory == null) {
            throw new RuntimeException("库存不存在：物资ID=" + detail.getMaterialId() + ", 批次号=" + detail.getBatchNo());
        }
        
        // 检查库存是否足够
        if (inventory.getQuantity() < detail.getQuantity()) {
            throw new RuntimeException("库存不足：物资ID=" + detail.getMaterialId() + ", 当前库存=" + inventory.getQuantity() + ", 出库数量=" + detail.getQuantity());
        }
        
        // 更新库存数量
        inventory.setQuantity(inventory.getQuantity() - detail.getQuantity());
        
        // 保存库存记录
        inventoryRepository.save(inventory);
    }
    
    @Override
    public WarehouseOut findById(Long id) {
        return warehouseOutRepository.findById(id).orElse(null);
    }
    
    @Override
    public WarehouseOut findByCode(String code) {
        return warehouseOutRepository.findByCode(code);
    }
    
    @Override
    public List<WarehouseOut> findByWarehouseId(Long warehouseId) {
        return warehouseOutRepository.findByWarehouseId(warehouseId);
    }
    
    @Override
    public List<WarehouseOut> findAll() {
        return warehouseOutRepository.findAll();
    }
    
    @Override
    public List<WarehouseOutDetail> findDetailsByOutId(Long outId) {
        return warehouseOutDetailRepository.findByOutId(outId);
    }
}
