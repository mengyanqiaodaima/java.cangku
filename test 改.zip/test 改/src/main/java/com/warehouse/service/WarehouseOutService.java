package com.warehouse.service;

import com.warehouse.entity.WarehouseOut;
import com.warehouse.entity.WarehouseOutDetail;
import java.util.List;

public interface WarehouseOutService {
    /**
     * 创建出库单并处理出库业务
     * @param warehouseOut 出库单信息
     * @param details 出库单明细
     * @return 创建的出库单
     */
    WarehouseOut createWarehouseOut(WarehouseOut warehouseOut, List<WarehouseOutDetail> details);
    
    /**
     * 根据ID查询出库单
     */
    WarehouseOut findById(Long id);
    
    /**
     * 根据编码查询出库单
     */
    WarehouseOut findByCode(String code);
    
    /**
     * 根据仓库ID查询出库单
     */
    List<WarehouseOut> findByWarehouseId(Long warehouseId);
    
    /**
     * 查询所有出库单
     */
    List<WarehouseOut> findAll();
    
    /**
     * 根据出库单ID查询出库单明细
     */
    List<WarehouseOutDetail> findDetailsByOutId(Long outId);
}
