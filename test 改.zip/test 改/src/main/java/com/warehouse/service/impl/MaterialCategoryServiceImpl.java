package com.warehouse.service.impl;

import com.warehouse.entity.MaterialCategory;
import com.warehouse.repository.MaterialCategoryRepository;
import com.warehouse.service.MaterialCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MaterialCategoryServiceImpl implements MaterialCategoryService {
    @Autowired
    private MaterialCategoryRepository materialCategoryRepository;
    
    @Override
    public MaterialCategory save(MaterialCategory category) {
        return materialCategoryRepository.save(category);
    }
    
    @Override
    public MaterialCategory update(MaterialCategory category) {
        return materialCategoryRepository.save(category);
    }
    
    @Override
    public void deleteById(Long id) {
        materialCategoryRepository.deleteById(id);
    }
    
    @Override
    public MaterialCategory findById(Long id) {
        return materialCategoryRepository.findById(id).orElse(null);
    }
    
    @Override
    public MaterialCategory findByCode(String code) {
        return materialCategoryRepository.findByCode(code);
    }
    
    @Override
    public List<MaterialCategory> findAll() {
        return materialCategoryRepository.findAll();
    }
    
    @Override
    public List<MaterialCategory> findByParentId(Long parentId) {
        return materialCategoryRepository.findByParentId(parentId);
    }
}
