package com.warehouse.service.impl;

import com.warehouse.entity.MaterialLedger;
import com.warehouse.repository.MaterialLedgerRepository;
import com.warehouse.service.MaterialLedgerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MaterialLedgerServiceImpl implements MaterialLedgerService {
    @Autowired
    private MaterialLedgerRepository materialLedgerRepository;
    
    @Override
    public MaterialLedger save(MaterialLedger materialLedger) {
        // 保存前验证物资编码唯一性
        if (!isCodeUnique(materialLedger.getCode(), materialLedger.getName(), 
                materialLedger.getSpecification(), materialLedger.getMaterial())) {
            throw new IllegalArgumentException("相同名称、规格、材质的物资不能使用相同的物资编码");
        }
        return materialLedgerRepository.save(materialLedger);
    }
    
    @Override
    public MaterialLedger update(MaterialLedger materialLedger) {
        // 更新前验证物资编码唯一性
        if (!isCodeUnique(materialLedger.getCode(), materialLedger.getName(), 
                materialLedger.getSpecification(), materialLedger.getMaterial())) {
            throw new IllegalArgumentException("相同名称、规格、材质的物资不能使用相同的物资编码");
        }
        return materialLedgerRepository.save(materialLedger);
    }
    
    @Override
    public void deleteById(Long id) {
        materialLedgerRepository.deleteById(id);
    }
    
    @Override
    public MaterialLedger findById(Long id) {
        return materialLedgerRepository.findById(id).orElse(null);
    }
    
    @Override
    public MaterialLedger findByCode(String code) {
        return materialLedgerRepository.findByCode(code);
    }
    
    @Override
    public List<MaterialLedger> findAll() {
        return materialLedgerRepository.findAll();
    }
    
    @Override
    public List<MaterialLedger> findByCategoryId(Long categoryId) {
        return materialLedgerRepository.findByCategoryId(categoryId);
    }
    
    @Override
    public boolean isCodeUnique(String code, String name, String specification, String material) {
        // 根据名称、规格、材质查询物资
        MaterialLedger existingMaterial = materialLedgerRepository.findByNameAndSpecificationAndMaterial(name, specification, material);
        
        // 如果不存在该物资，则编码唯一
        if (existingMaterial == null) {
            return true;
        }
        
        // 如果存在该物资，检查编码是否相同
        return existingMaterial.getCode().equals(code);
    }
}
