package com.warehouse.service;

import com.warehouse.entity.Inventory;
import java.util.List;
import java.util.Map;

public interface InventoryService {
    /**
     * 根据物资ID和仓库ID查询库存信息
     */
    List<Inventory> findByMaterialIdAndWarehouseId(Long materialId, Long warehouseId);
    
    /**
     * 根据仓库ID查询所有库存
     */
    List<Inventory> findByWarehouseId(Long warehouseId);
    
    /**
     * 查询所有库存
     */
    List<Inventory> findAll();
    
    /**
     * 按物资编码查询库存信息（包括物资详情）
     */
    List<Map<String, Object>> findInventoryByMaterialCode(String materialCode);
    
    /**
     * 按物资分类汇总查询库存信息
     */
    List<Map<String, Object>> findInventoryByCategoryId(Long categoryId);
}
