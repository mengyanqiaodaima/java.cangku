package com.warehouse.service;

import com.warehouse.entity.Warehouse;
import java.util.List;

public interface WarehouseService {
    /**
     * 新增仓库
     */
    Warehouse save(Warehouse warehouse);
    
    /**
     * 更新仓库
     */
    Warehouse update(Warehouse warehouse);
    
    /**
     * 根据ID删除仓库
     */
    void deleteById(Long id);
    
    /**
     * 根据ID查询仓库
     */
    Warehouse findById(Long id);
    
    /**
     * 根据编码查询仓库
     */
    Warehouse findByCode(String code);
    
    /**
     * 查询所有仓库
     */
    List<Warehouse> findAll();
}
