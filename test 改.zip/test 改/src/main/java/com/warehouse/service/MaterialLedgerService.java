package com.warehouse.service;

import com.warehouse.entity.MaterialLedger;
import java.util.List;

public interface MaterialLedgerService {
    /**
     * 新增物资台账
     */
    MaterialLedger save(MaterialLedger materialLedger);
    
    /**
     * 更新物资台账
     */
    MaterialLedger update(MaterialLedger materialLedger);
    
    /**
     * 根据ID删除物资台账
     */
    void deleteById(Long id);
    
    /**
     * 根据ID查询物资台账
     */
    MaterialLedger findById(Long id);
    
    /**
     * 根据编码查询物资台账
     */
    MaterialLedger findByCode(String code);
    
    /**
     * 查询所有物资台账
     */
    List<MaterialLedger> findAll();
    
    /**
     * 根据分类ID查询物资台账
     */
    List<MaterialLedger> findByCategoryId(Long categoryId);
    
    /**
     * 验证物资编码的唯一性
     * @param code 物资编码
     * @param name 物资名称
     * @param specification 规格
     * @param material 材质
     * @return 是否唯一
     */
    boolean isCodeUnique(String code, String name, String specification, String material);
}
