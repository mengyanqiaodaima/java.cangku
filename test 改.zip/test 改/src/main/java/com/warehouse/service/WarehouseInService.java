package com.warehouse.service;

import com.warehouse.entity.WarehouseIn;
import com.warehouse.entity.WarehouseInDetail;
import java.util.List;

public interface WarehouseInService {
    /**
     * 创建入库单并处理入库业务
     * @param warehouseIn 入库单信息
     * @param details 入库单明细
     * @return 创建的入库单
     */
    WarehouseIn createWarehouseIn(WarehouseIn warehouseIn, List<WarehouseInDetail> details);
    
    /**
     * 根据ID查询入库单
     */
    WarehouseIn findById(Long id);
    
    /**
     * 根据编码查询入库单
     */
    WarehouseIn findByCode(String code);
    
    /**
     * 根据仓库ID查询入库单
     */
    List<WarehouseIn> findByWarehouseId(Long warehouseId);
    
    /**
     * 查询所有入库单
     */
    List<WarehouseIn> findAll();
    
    /**
     * 根据入库单ID查询入库单明细
     */
    List<WarehouseInDetail> findDetailsByInId(Long inId);
}
