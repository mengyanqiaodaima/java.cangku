package com.warehouse.service.impl;

import com.warehouse.entity.Inventory;
import com.warehouse.entity.WarehouseIn;
import com.warehouse.entity.WarehouseInDetail;
import com.warehouse.repository.InventoryRepository;
import com.warehouse.repository.WarehouseInDetailRepository;
import com.warehouse.repository.WarehouseInRepository;
import com.warehouse.service.WarehouseInService;
import com.warehouse.utils.CodeGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class WarehouseInServiceImpl implements WarehouseInService {
    @Autowired
    private WarehouseInRepository warehouseInRepository;
    
    @Autowired
    private WarehouseInDetailRepository warehouseInDetailRepository;
    
    @Autowired
    private InventoryRepository inventoryRepository;
    
    @Override
    @Transactional
    public WarehouseIn createWarehouseIn(WarehouseIn warehouseIn, List<WarehouseInDetail> details) {
        // 生成入库单编码
        String code = CodeGenerator.generateInCode();
        warehouseIn.setCode(code);
        
        // 保存入库单
        WarehouseIn savedIn = warehouseInRepository.save(warehouseIn);
        
        // 保存入库单明细并更新库存
        for (WarehouseInDetail detail : details) {
            // 设置入库单ID
            detail.setInId(savedIn.getId());
            
            // 保存明细
            warehouseInDetailRepository.save(detail);
            
            // 更新库存
            updateInventory(savedIn.getWarehouseId(), detail);
        }
        
        return savedIn;
    }
    
    /**
     * 更新库存信息
     * 如果库存记录不存在，创建新记录；如果存在，更新库存数量
     */
    private void updateInventory(Long warehouseId, WarehouseInDetail detail) {
        // 查询当前库存
        Inventory inventory = inventoryRepository.findByMaterialIdAndWarehouseIdAndBatchNo(
                detail.getMaterialId(), warehouseId, detail.getBatchNo());
        
        if (inventory == null) {
            // 创建新的库存记录
            inventory = new Inventory();
            inventory.setMaterialId(detail.getMaterialId());
            inventory.setWarehouseId(warehouseId);
            inventory.setQuantity(detail.getQuantity());
            inventory.setBatchNo(detail.getBatchNo());
        } else {
            // 更新库存数量
            inventory.setQuantity(inventory.getQuantity() + detail.getQuantity());
        }
        
        // 保存库存记录
        inventoryRepository.save(inventory);
    }
    
    @Override
    public WarehouseIn findById(Long id) {
        return warehouseInRepository.findById(id).orElse(null);
    }
    
    @Override
    public WarehouseIn findByCode(String code) {
        return warehouseInRepository.findByCode(code);
    }
    
    @Override
    public List<WarehouseIn> findByWarehouseId(Long warehouseId) {
        return warehouseInRepository.findByWarehouseId(warehouseId);
    }
    
    @Override
    public List<WarehouseIn> findAll() {
        return warehouseInRepository.findAll();
    }
    
    @Override
    public List<WarehouseInDetail> findDetailsByInId(Long inId) {
        return warehouseInDetailRepository.findByInId(inId);
    }
}
