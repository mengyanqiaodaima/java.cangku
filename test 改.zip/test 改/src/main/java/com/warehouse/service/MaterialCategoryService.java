package com.warehouse.service;

import com.warehouse.entity.MaterialCategory;
import java.util.List;

public interface MaterialCategoryService {
    /**
     * 新增物资分类
     */
    MaterialCategory save(MaterialCategory category);
    
    /**
     * 更新物资分类
     */
    MaterialCategory update(MaterialCategory category);
    
    /**
     * 根据ID删除物资分类
     */
    void deleteById(Long id);
    
    /**
     * 根据ID查询物资分类
     */
    MaterialCategory findById(Long id);
    
    /**
     * 根据编码查询物资分类
     */
    MaterialCategory findByCode(String code);
    
    /**
     * 查询所有物资分类
     */
    List<MaterialCategory> findAll();
    
    /**
     * 根据父分类ID查询子分类
     */
    List<MaterialCategory> findByParentId(Long parentId);
}
