package com.warehouse.repository;

import com.warehouse.entity.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InventoryRepository extends JpaRepository<Inventory, Long> {
    // 根据物资ID、仓库ID和批次号查询库存
    Inventory findByMaterialIdAndWarehouseIdAndBatchNo(Long materialId, Long warehouseId, String batchNo);
    
    // 根据物资ID和仓库ID查询所有批次库存
    java.util.List<Inventory> findByMaterialIdAndWarehouseId(Long materialId, Long warehouseId);
    
    // 根据仓库ID查询所有库存
    java.util.List<Inventory> findByWarehouseId(Long warehouseId);
}
