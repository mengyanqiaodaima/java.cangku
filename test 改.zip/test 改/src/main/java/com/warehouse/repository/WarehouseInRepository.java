package com.warehouse.repository;

import com.warehouse.entity.WarehouseIn;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface WarehouseInRepository extends JpaRepository<WarehouseIn, Long> {
    // 根据入库单编码查询
    WarehouseIn findByCode(String code);
    
    // 根据仓库ID查询入库单
    java.util.List<WarehouseIn> findByWarehouseId(Long warehouseId);
}
