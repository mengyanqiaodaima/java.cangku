package com.warehouse.repository;

import com.warehouse.entity.MaterialLedger;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MaterialLedgerRepository extends JpaRepository<MaterialLedger, Long> {
    // 根据物资编码查询
    MaterialLedger findByCode(String code);
    
    // 根据物资名称、规格、材质查询（用于验证唯一性约束）
    MaterialLedger findByNameAndSpecificationAndMaterial(String name, String specification, String material);
    
    // 根据分类ID查询物资
    java.util.List<MaterialLedger> findByCategoryId(Long categoryId);
}
