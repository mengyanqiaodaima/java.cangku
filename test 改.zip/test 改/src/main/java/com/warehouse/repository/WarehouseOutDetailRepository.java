package com.warehouse.repository;

import com.warehouse.entity.WarehouseOutDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface WarehouseOutDetailRepository extends JpaRepository<WarehouseOutDetail, Long> {
    // 根据出库单ID查询明细
    java.util.List<WarehouseOutDetail> findByOutId(Long outId);
}
