package com.warehouse.repository;

import com.warehouse.entity.WarehouseOut;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface WarehouseOutRepository extends JpaRepository<WarehouseOut, Long> {
    // 根据出库单编码查询
    WarehouseOut findByCode(String code);
    
    // 根据仓库ID查询出库单
    java.util.List<WarehouseOut> findByWarehouseId(Long warehouseId);
}
