package com.warehouse.repository;

import com.warehouse.entity.MaterialCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MaterialCategoryRepository extends JpaRepository<MaterialCategory, Long> {
    // 根据分类编码查询
    MaterialCategory findByCode(String code);
    
    // 根据父分类ID查询子分类
    java.util.List<MaterialCategory> findByParentId(Long parentId);
}
