package com.warehouse.repository;

import com.warehouse.entity.WarehouseInDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface WarehouseInDetailRepository extends JpaRepository<WarehouseInDetail, Long> {
    // 根据入库单ID查询明细
    java.util.List<WarehouseInDetail> findByInId(Long inId);
}
