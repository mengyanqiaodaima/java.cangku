package com.warehouse.common;

import lombok.Data;

/**
 * 统一响应结果类
 */
@Data
public class Result<T> {
    // 状态码：200表示成功，其他表示失败
    private int code;
    // 消息：成功或失败的描述
    private String message;
    // 数据：返回的数据
    private T data;
    
    // 私有构造方法
    private Result(int code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }
    
    /**
     * 成功响应
     */
    public static <T> Result<T> success(T data) {
        return new Result<>(200, "success", data);
    }
    
    /**
     * 成功响应，不带数据
     */
    public static <T> Result<T> success() {
        return new Result<>(200, "success", null);
    }
    
    /**
     * 失败响应
     */
    public static <T> Result<T> error(int code, String message) {
        return new Result<>(code, message, null);
    }
    
    /**
     * 默认失败响应
     */
    public static <T> Result<T> error(String message) {
        return new Result<>(500, message, null);
    }
}