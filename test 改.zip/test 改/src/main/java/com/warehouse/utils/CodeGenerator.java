package com.warehouse.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 编码生成工具类
 * 生成业务单据编码，采用年月日+流水号的方式
 */
public class CodeGenerator {
    // 流水号计数器
    private static final AtomicInteger IN_COUNTER = new AtomicInteger(0);
    private static final AtomicInteger OUT_COUNTER = new AtomicInteger(0);
    
    // 日期格式化
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyyMMdd");
    
    // 重置计数器的阈值
    private static final int COUNTER_THRESHOLD = 9999;
    
    // 上一次生成编码的日期
    private static String lastInDate = "";
    private static String lastOutDate = "";
    
    /**
     * 生成入库单编码
     * 格式：RK+年月日+4位流水号（如：RK202311200001）
     */
    public synchronized static String generateInCode() {
        String currentDate = DATE_FORMAT.format(new Date());
        
        // 如果日期发生变化，重置计数器
        if (!currentDate.equals(lastInDate)) {
            IN_COUNTER.set(0);
            lastInDate = currentDate;
        }
        
        // 增加计数器
        int count = IN_COUNTER.incrementAndGet();
        
        // 如果计数器超过阈值，重置为1
        if (count > COUNTER_THRESHOLD) {
            IN_COUNTER.set(1);
            count = 1;
        }
        
        // 生成编码
        return "RK" + currentDate + String.format("%04d", count);
    }
    
    /**
     * 生成出库单编码
     * 格式：CK+年月日+4位流水号（如：CK202311200001）
     */
    public synchronized static String generateOutCode() {
        String currentDate = DATE_FORMAT.format(new Date());
        
        // 如果日期发生变化，重置计数器
        if (!currentDate.equals(lastOutDate)) {
            OUT_COUNTER.set(0);
            lastOutDate = currentDate;
        }
        
        // 增加计数器
        int count = OUT_COUNTER.incrementAndGet();
        
        // 如果计数器超过阈值，重置为1
        if (count > COUNTER_THRESHOLD) {
            OUT_COUNTER.set(1);
            count = 1;
        }
        
        // 生成编码
        return "CK" + currentDate + String.format("%04d", count);
    }
}
